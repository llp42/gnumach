#!/bin/sh
# GNU Mach ABI test suite runner (x86_64).
#
# Copyright (C) 2024 Free Software Foundation
#
# This program is free software ; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation ; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY ; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# This script is self-contained: it only uses its own directory
# (modules/ and grub.cfg.template) plus the kernel image given on the
# command line.  It never touches the source repository.

set -u

ARCH=x86_64
QEMU_BIN_DEFAULT=qemu-system-x86_64
QEMU_CPU=core2duo-v1

TEST_START_MARKER="booting-start-of-test"
TEST_SUCCESS_MARKER="gnumach-test-success-and-reboot"
TEST_FAILURE_MARKER="gnumach-test-failure"

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd) || exit 2
MODULES_DIR=$SCRIPT_DIR/modules
TEMPLATE=$SCRIPT_DIR/grub.cfg.template

TIMEOUT=120
SMP=2
QEMU_BIN=
GRUB_MKRESCUE_BIN=
KEEP_LOGS=no
LOG_DIR=
LIST=no
KERNEL=
SELECTED=

die() {
    printf 'error: %s\n' "$*" >&2
    exit 2
}

usage() {
    cat <<EOF
Usage: $(basename -- "$0") <gnumach-image> [options]

Run the GNU Mach ABI test suite (x86_64) against <gnumach-image>.

Options:
  --test NAME          run only the given test (repeatable). 'test-foo',
                       'module-foo' and 'foo' all select test-foo.  The
                       test-multiboot check always runs first as a gate.
  --list               list the available tests and exit
  --timeout SEC        timeout for each QEMU run (default: 120)
  --smp N              number of CPUs QEMU should provide (default: 2).
                       This must match the kernel's NCPUS
                       (--enable-ncpus=N); the pack is validated with
                       NCPUS=2, so QEMU is started with -smp 2 as in
                       tests/user-qemu.mk.
  --qemu BIN           QEMU binary (default: $QEMU_BIN_DEFAULT)
  --grub-mkrescue BIN  grub-mkrescue/grub2-mkrescue binary to use
  --keep-logs          keep the per-test temporary directory and its log
  --log-dir DIR        write the test logs to DIR
  -h, --help           show this help

Exit status: 0 if all selected tests passed, 1 if a test failed, 2 on
usage errors or missing tools.
EOF
}

while [ $# -gt 0 ]; do
    case $1 in
    --test)
        [ $# -ge 2 ] || die "option --test requires an argument"
        SELECTED="$SELECTED $2"
        shift 2
        ;;
    --test=*)
        SELECTED="$SELECTED ${1#--test=}"
        shift
        ;;
    --timeout)
        [ $# -ge 2 ] || die "option --timeout requires an argument"
        TIMEOUT=$2
        shift 2
        ;;
    --timeout=*)
        TIMEOUT=${1#--timeout=}
        shift
        ;;
    --smp)
        [ $# -ge 2 ] || die "option --smp requires an argument"
        SMP=$2
        shift 2
        ;;
    --smp=*)
        SMP=${1#--smp=}
        shift
        ;;
    --qemu)
        [ $# -ge 2 ] || die "option --qemu requires an argument"
        QEMU_BIN=$2
        shift 2
        ;;
    --qemu=*)
        QEMU_BIN=${1#--qemu=}
        shift
        ;;
    --grub-mkrescue)
        [ $# -ge 2 ] || die "option --grub-mkrescue requires an argument"
        GRUB_MKRESCUE_BIN=$2
        shift 2
        ;;
    --grub-mkrescue=*)
        GRUB_MKRESCUE_BIN=${1#--grub-mkrescue=}
        shift
        ;;
    --keep-logs)
        KEEP_LOGS=yes
        shift
        ;;
    --log-dir)
        [ $# -ge 2 ] || die "option --log-dir requires an argument"
        LOG_DIR=$2
        shift 2
        ;;
    --log-dir=*)
        LOG_DIR=${1#--log-dir=}
        shift
        ;;
    --list)
        LIST=yes
        shift
        ;;
    -h|--help)
        usage
        exit 0
        ;;
    --)
        shift
        while [ $# -gt 0 ]; do
            if [ -z "$KERNEL" ]; then
                KERNEL=$1
            else
                die "unexpected argument: $1"
            fi
            shift
        done
        ;;
    -*)
        die "unknown option: $1 (try --help)"
        ;;
    *)
        if [ -z "$KERNEL" ]; then
            KERNEL=$1
        else
            die "unexpected argument: $1"
        fi
        shift
        ;;
    esac
done

case $TIMEOUT in
''|*[!0-9]*)
    die "invalid timeout: $TIMEOUT"
    ;;
esac
[ "$TIMEOUT" -gt 0 ] || die "invalid timeout: $TIMEOUT"

case $SMP in
''|*[!0-9]*)
    die "invalid SMP setting: $SMP"
    ;;
esac
[ "$SMP" -gt 0 ] || die "invalid SMP setting: $SMP"

all_tests() {
    printf '%s\n' test-multiboot
    for m in "$MODULES_DIR"/module-*; do
        [ -e "$m" ] || continue
        printf 'test-%s\n' "$(basename -- "$m" | sed 's/^module-//')"
    done | LC_ALL=C sort
}

normalize_test() {
    case $1 in
    test-*)
        printf '%s\n' "$1"
        ;;
    module-*)
        printf 'test-%s\n' "${1#module-}"
        ;;
    *)
        printf 'test-%s\n' "$1"
        ;;
    esac
}

ALL_TESTS_LIST=$(all_tests)
ALL_TESTS=$(printf '%s\n' "$ALL_TESTS_LIST" | tr '\n' ' ')

if [ "$LIST" = yes ]; then
    printf '%s\n' "$ALL_TESTS_LIST"
    exit 0
fi

if [ -n "$SELECTED" ]; then
    wanted=
    for s in $SELECTED; do
        t=$(normalize_test "$s")
        case " $ALL_TESTS " in
        *" $t "*) ;;
        *) die "unknown test: $s (use --list to list the available tests)" ;;
        esac
        case " $wanted " in
        *" $t "*) ;;
        *) wanted="$wanted $t" ;;
        esac
    done
    selected=$wanted
else
    selected=$ALL_TESTS
fi

# The multiboot check is a cheap gate: always run it first and never boot
# anything if it fails, otherwise every test would just time out.
EFFECTIVE=" test-multiboot"
for t in $selected; do
    [ "$t" = test-multiboot ] && continue
    EFFECTIVE="$EFFECTIVE $t"
done

[ -n "$KERNEL" ] || {
    usage >&2
    die "missing <gnumach-image> argument"
}
[ -f "$KERNEL" ] || die "kernel image not found: $KERNEL"
[ -r "$KERNEL" ] || die "kernel image not readable: $KERNEL"
[ -f "$TEMPLATE" ] || die "template not found: $TEMPLATE"

find_tool() {
    override=$1
    shift
    if [ -n "$override" ]; then
        if command -v "$override" >/dev/null 2>&1; then
            printf '%s\n' "$override"
            return 0
        fi
        return 1
    fi
    for candidate in "$@"; do
        if command -v "$candidate" >/dev/null 2>&1; then
            printf '%s\n' "$candidate"
            return 0
        fi
    done
    return 1
}

QEMU=$(find_tool "$QEMU_BIN" "$QEMU_BIN_DEFAULT") ||
    die "QEMU binary not found: ${QEMU_BIN:-$QEMU_BIN_DEFAULT}"
GRUB_MKRESCUE=$(find_tool "$GRUB_MKRESCUE_BIN" grub-mkrescue grub2-mkrescue) ||
    die "grub-mkrescue not found (install grub, or use --grub-mkrescue)"
GRUB_FILE=$(find_tool "" grub-file grub2-file) ||
    die "grub-file/grub2-file not found"
TIMEOUT_BIN=$(find_tool "" timeout) ||
    die "timeout not found"

if [ -n "$LOG_DIR" ]; then
    mkdir -p "$LOG_DIR" || die "cannot create log directory: $LOG_DIR"
fi

run_qemu_test() {
    test_name=$1
    module=module-${test_name#test-}
    module_path=$MODULES_DIR/$module

    [ -f "$module_path" ] || die "module not found: $module_path"

    workdir=$(mktemp -d "${TMPDIR:-/tmp}/abi-test-$ARCH.XXXXXX") ||
        die "cannot create temporary directory"
    mkdir -p "$workdir/boot/grub" || die "cannot create $workdir/boot/grub"

    # Only <module-file> is a placeholder expanded here.  The '${host-port}',
    # '$(task-create)', ... tokens are expanded by the kernel's boot script,
    # not by GRUB, so they must be kept verbatim.
    sed "s|<module-file>|$module|g" "$TEMPLATE" >"$workdir/boot/grub/grub.cfg" ||
        die "cannot render $workdir/boot/grub/grub.cfg"
    cp "$KERNEL" "$workdir/boot/gnumach" || die "cannot copy kernel image"
    cp "$module_path" "$workdir/boot/$module" || die "cannot copy module"

    if ! "$GRUB_MKRESCUE" -o "$workdir/test.iso" "$workdir" \
        >"$workdir/mkrescue.log" 2>&1; then
        printf 'FAIL: %s (grub-mkrescue failed)\n' "$test_name"
        sed 's/^/    /' "$workdir/mkrescue.log" >&2
        rm -rf "$workdir"
        return 1
    fi

    if [ -n "$LOG_DIR" ]; then
        log=$LOG_DIR/$test_name.log
    else
        log=$workdir/test.log
    fi

    "$TIMEOUT_BIN" --foreground --kill-after=3 "${TIMEOUT}s" \
        "$QEMU" -m 2047 -nographic -no-reboot -monitor none -serial stdio \
        -boot d -cpu "$QEMU_CPU" -smp "$SMP" -cdrom "$workdir/test.iso" \
        </dev/null >"$log" 2>&1
    rc=$?

    if [ "$rc" -eq 124 ] || [ "$rc" -eq 137 ]; then
        reason="timeout after ${TIMEOUT}s"
        result=1
    elif grep -qi "$TEST_FAILURE_MARKER" "$log"; then
        reason="failure marker '$TEST_FAILURE_MARKER' found"
        result=1
    elif ! grep -q "$TEST_SUCCESS_MARKER" "$log"; then
        reason="missing success marker (QEMU exit status $rc)"
        result=1
    else
        reason=
        result=0
    fi

    if [ "$result" -ne 0 ]; then
        printf 'FAIL: %s (%s)\n' "$test_name" "$reason"
        if [ -f "$log" ]; then
            printf -- '---- last lines of %s ----\n' "$log"
            tail -n 15 "$log" | sed 's/^/    /'
            printf -- '------------------------------\n'
        fi
    else
        printf 'PASS: %s\n' "$test_name"
    fi

    if [ -n "$LOG_DIR" ]; then
        rm -rf "$workdir"
    elif [ "$KEEP_LOGS" = yes ]; then
        printf 'log kept: %s\n' "$log"
    else
        rm -rf "$workdir"
    fi

    return "$result"
}

total=0
passed=0
failed=0
multiboot_failed=no

for test_name in $EFFECTIVE; do
    if [ "$test_name" = test-multiboot ]; then
        total=$((total + 1))
        if mberr=$("$GRUB_FILE" --is-x86-multiboot "$KERNEL" 2>&1); then
            printf 'PASS: test-multiboot\n'
            passed=$((passed + 1))
        else
            printf 'FAIL: test-multiboot (%s is not an x86 multiboot kernel)\n' \
                "$KERNEL"
            [ -n "$mberr" ] && printf '%s\n' "$mberr" | sed 's/^/    /'
            printf 'error: %s failed the multiboot check; aborting without booting any test\n' \
                "$KERNEL" >&2
            failed=$((failed + 1))
            multiboot_failed=yes
            break
        fi
    else
        total=$((total + 1))
        if run_qemu_test "$test_name"; then
            passed=$((passed + 1))
        else
            failed=$((failed + 1))
        fi
    fi
done

printf '\nSUMMARY: %d/%d tests passed\n' "$passed" "$total"
printf 'RESULT: passed=%d failed=%d total=%d\n' "$passed" "$failed" "$total"

if [ "$multiboot_failed" = yes ]; then
    exit 1
fi
[ "$failed" -eq 0 ] || exit 1
exit 0
