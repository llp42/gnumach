# GNU Mach ABI test suite -- i386 pack

Frozen binary pack of the GNU Mach ABI test suite for i386: 25
freestanding user-space ELF test modules plus the `test-multiboot` kernel
check, i.e. 26 tests in total.  The pack was built from the `abi-tests`
branch at commit `2fbf950f` (see `VERSION`).

Everything needed to run the tests is inside this directory; the pack does
not depend on the GNU Mach source tree or on the repository it came from.

## Contents

| Path                  | Description                                          |
| --------------------- | ---------------------------------------------------- |
| `run-i386.sh`     | test runner (see below)                              |
| `modules/module-*`    | 25 frozen freestanding user-space ELF test modules   |
| `grub.cfg.template`   | GRUB configuration template used to build each ISO   |
| `VERSION`             | provenance of the pack                               |
| `README.md`           | this file                                            |

## Requirements

* `qemu-system-i386` (QEMU)
* `grub-mkrescue` or `grub2-mkrescue`, plus `xorriso`
  (`grub-mkrescue` usually invokes `xorriso` itself)
* `grub-file` or `grub2-file` (for the `test-multiboot` check)
* GNU `timeout` (coreutils)
* a GNU Mach i386 kernel image (the `gnumach` binary)

The kernel must be built with `--enable-ncpus=2`; the suite is validated
with NCPUS=2 kernels.  Other kernel configurations should work too, but
they are not the validated configuration.

The QEMU command used per test is the one from the repository's
`tests/user-qemu.mk`:

```
qemu-system-i386 -m 2047 -nographic -no-reboot -monitor none \
    -serial stdio -boot d -cpu pentium3-v1 -smp 2 -cdrom test.iso
```

`-smp` matches the kernel's `NCPUS`.  The suite is validated with NCPUS=2
kernels (`tests/user-qemu.mk` adds `-smp 2` when SMP is enabled), which is
why the runner defaults to `--smp 2`.

## Usage

```
./run-i386.sh <gnumach-image> [options]
```

Options:

* `--test NAME` -- run only the given test (repeatable).  `test-foo`,
  `module-foo` and `foo` all select `test-foo`.  `test-multiboot` always
  runs first as a gate, even when specific module tests are selected.
* `--list` -- list the available tests and exit.
* `--timeout SEC` -- QEMU timeout per test (default: 120).
* `--smp N` -- number of CPUs QEMU should provide (default: 2).  This must
  match the kernel's `NCPUS`; use `--smp 1` for an NCPUS=1 kernel.
* `--qemu BIN` -- QEMU binary (default: `qemu-system-i386`).
* `--grub-mkrescue BIN` -- `grub-mkrescue`/`grub2-mkrescue` binary to use.
* `--keep-logs` -- keep the per-test temporary directory (and its log).
* `--log-dir DIR` -- write the test logs to `DIR` instead of a temporary
  directory.
* `-h`, `--help` -- show the help text.

Examples:

```
./run-i386.sh /path/to/gnumach
./run-i386.sh /path/to/gnumach --list
./run-i386.sh /path/to/gnumach --test hello --test vm-abi
./run-i386.sh /path/to/gnumach --log-dir /tmp/abi-logs
```

The runner prints one `PASS: test-X` or `FAIL: test-X (reason)` line per
test, followed by a summary:

```
SUMMARY: 26/26 tests passed
RESULT: passed=26 failed=0 total=26
```

The exit status is 0 if all selected tests passed, 1 if a test failed and
2 on usage errors, a missing kernel, a missing tool or an unknown test.

## Verdict rules

For each booted test the serial output is searched for the test markers
used by the GNU Mach test suite:

* failure marker `gnumach-test-failure` found -> FAIL;
* success marker `gnumach-test-success-and-reboot` missing
  (crash or timeout) -> FAIL;
* timeout (QEMU killed after `--timeout` seconds) -> FAIL;
* otherwise -> PASS.

If the `test-multiboot` check fails, the runner prints a clear error and
stops before booting anything, because no test could succeed on a kernel
that GRUB cannot boot.
